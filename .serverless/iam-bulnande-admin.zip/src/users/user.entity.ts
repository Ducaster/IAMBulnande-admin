export class User {
  id: string;
  password: string;
  refreshToken?: string;
}
